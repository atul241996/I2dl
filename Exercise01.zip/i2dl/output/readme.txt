This folder will contain all zipped exercises which you
will use to upload to our submission webpage.