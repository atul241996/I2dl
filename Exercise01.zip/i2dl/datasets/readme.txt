The exercises have relative paths set based on folder structure as:

i2dl_exercises
        ├── datasets                   # The current folder
            ├── cifar10                # Dataset directory
                ├── cifar10.p          # dataset files